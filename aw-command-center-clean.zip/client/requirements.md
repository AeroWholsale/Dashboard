## Packages
recharts | For data visualization (charts, sparklines)
framer-motion | For smooth page transitions and micro-interactions
lucide-react | For icons (already in base, but ensuring it's noted)
date-fns | For date formatting
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
The dashboard uses a dark professional theme.
Sidebar navigation is required.
Recharts will be used for sparklines and bar charts.
